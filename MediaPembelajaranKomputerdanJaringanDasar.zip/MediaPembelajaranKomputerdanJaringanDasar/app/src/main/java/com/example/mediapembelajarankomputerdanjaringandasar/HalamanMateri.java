package com.example.mediapembelajarankomputerdanjaringandasar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

public class HalamanMateri extends Activity {

    CardView cardMateri1;
    CardView cardMateri2;
    CardView cardMateri3;
    CardView cardMateri4;
    CardView cardMateri5;
    CardView cardMateri6;
    CardView cardMateri7;
    CardView cardMateri8;
    CardView cardMateri9;
    CardView cardMateri10;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_materi_admin);

        cardMateri1 = findViewById(R.id.cardMateri1);
        cardMateri2 = findViewById(R.id.cardMateri2);
        cardMateri3 = findViewById(R.id.cardMateri3);
        cardMateri4 = findViewById(R.id.cardMateri4);
        cardMateri5 = findViewById(R.id.cardMateri5);
        cardMateri6 = findViewById(R.id.cardMateri6);
        cardMateri7 = findViewById(R.id.cardMateri7);
        cardMateri8 = findViewById(R.id.cardMateri8);
        cardMateri9 = findViewById(R.id.cardMateri9);
        cardMateri10 = findViewById(R.id.cardMateri10);

        cardMateri1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab1_Siswa.class));
            }
        });
        cardMateri2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab2_Siswa.class));
            }
        });
        cardMateri3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab3_Siswa.class));
            }
        });
        cardMateri4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab4_Siswa.class));
            }
        });
        cardMateri5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab5_Siswa.class));
            }
        });
        cardMateri6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab6_Siswa.class));
            }
        });
        cardMateri7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab7_Siswa.class));
            }
        });
        cardMateri8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab8_Siswa.class));
            }
        });
        cardMateri9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab9_Siswa.class));
            }
        });
        cardMateri10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateri.this, MainActivityBab10_Siswa.class));
            }
        });
    }
}