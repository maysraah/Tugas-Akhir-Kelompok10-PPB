package com.example.mediapembelajarankomputerdanjaringandasar;

public class Bab4Model {
    String key, judul_sub,deskripsi,image;

    public Bab4Model() {
        // dibutuhkan oleh Firebase
    }

    public Bab4Model(String key, String judul_sub, String deskripsi) {
        this.key = key;
        this.judul_sub = judul_sub;
        this.deskripsi = deskripsi;
    }

    public void setImage(String Image){
        this.image = Image;
    }
    public String getImage(){
        return image;
    }
    public void setKey(String key){
        this.key = key;
    }

    public String getkey() {
        return key;
    }

    public String getJudul_sub() {
        return judul_sub;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
}
