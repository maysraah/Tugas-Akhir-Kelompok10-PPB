package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivityBab2_Siswa extends AppCompatActivity {
    private DatabaseReference database;
    ListView listView;
    private ArrayList<Bab2Model> listBab2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bab2_siswa);
        listView = findViewById(R.id.itemsList);

        //menginsiasi database Firebase
        database = FirebaseDatabase.getInstance().getReference();
        populateDataBab2();
    }

    public void populateListview(){
        try {
            ItemListAdapterBab2 itemsAdopter = new ItemListAdapterBab2(this, listBab2);
            listView.setAdapter(itemsAdopter);
            itemsAdopter.notifyDataSetChanged();
            registerForContextMenu(listView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void populateDataBab2 () {
        database.child("Bab 2").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listBab2 = new ArrayList<>();
                for (DataSnapshot materiSnapshot : snapshot.getChildren()) {
                    Bab2Model Bab2 = materiSnapshot.getValue(Bab2Model.class);
                    Bab2.setKey(materiSnapshot.getKey());
                    listBab2.add(Bab2);
                }
                populateListview();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        populateDataBab2();
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu_2, menu);

    }

    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Bab2Model materi = listBab2.get(info.position);
        switch (item.getItemId()) {
            case R.id.detail:
                Intent detail = new Intent(MainActivityBab2_Siswa.this, DetailBab2.class);
                detail.putExtra("key", materi.getkey());
                startActivity(detail);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}