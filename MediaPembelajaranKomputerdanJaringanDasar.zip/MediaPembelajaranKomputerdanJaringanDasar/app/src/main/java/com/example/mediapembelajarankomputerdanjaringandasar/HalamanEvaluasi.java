package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class HalamanEvaluasi extends AppCompatActivity {

    TextView kuis;
    RadioGroup rg;
    RadioButton PilihanA, PilihanB, PilihanC, PilihanD;
    int nomor = 0;
    public static int hasil, benar, salah;

    // Pertanyaan
    String[] soal_kuis = new String[] {
            "Kepanjangan dari K3LH adalah ...",
            "'Upaya untuk mengetahui, mengenal, dan memperkirakan adanya bahaya pada suatu sistem seperti peralatan, tempat kerja, proses kerja, prosedur, dan lain-lain' merupakan pengertian dari...",
            "Berikut alat-alat yang digunakan untukk merakit komputer, kecuali ...",
            "Benda yang berfungsi sebagai 'rumah' dari semua komponen hardware komputer disebut ...",
            "'Memulai perakitan komponen-komponen komputer dengan memasang satu persatu hardware yang diperlukan' merupakan pengertian merakit komputer pada tahap ...",
            "Berikut kode yang akan diberikan komputer bila terjadi masalah, yaitu ...",
            "Sistem Operasi termasuk dalam perangkat lunak ...",
            "Berikut sistem operasi pada komputer, kecuali ...",
            "Sistem Operasi mempunyai 2 jenis antarmuka, yaitu ...",
            "'Software yang memiliki tugas mengontrol hardware yang terpasang di komputer agar bisa terkoneksi dengan OS, aplikasi lain atau perangkat yang lain' merupakan pengertian dari ..."
    };

    // Pilihan Jawaban
    String[] pilihan_jawaban = new String[] {
            "Kesehatan, Keselamatan, dan Keamanan dan Lingkungan Hidup", "Kesehatan, Keselamatan, dan Kesejahteraan dan Lingkungan Hidup", "Keuntungan, Keselamatan, dan Kesejahteraan dan Lingkungan Hidup", "Keberhasilan, Keselamatan, dan Keamanan dan Lingkungan Hidup",
            "Identifikasi Keselamatan", "Identifikasi Bahaya", "Identifikasi Kesalahan", "Identifikasi Risiko",
            "Obeng Plus (+)", "Obeng Minus (-)", "Tang Lancip (capit buaya)", "Tang Krimping",
            "Cassing", "Motherboard", "CPU", "RAM",
            "Pengujian", "Persiapan", "Proses Perakitan", "Penanganan Masalah",
            "Kode Suara Beep", "Kode Suara Ting", "Kode Suara Kring", "Kode Suara Klik",
            "Aplikasi", "Open Source", "Sistem", "Semua Benar",
            "LINUX", "Android", "Windows", "MacOS",
            "CLI dan GUI", "CLI dan GNU", "GPU dan GNU", "Software dan Hardware",
            "Sistem Operasi", "Interface", "Hardware", "Driver"
    };

    // Jawaban
    String[] jawaban = new String[] {
            "Kesehatan, Keselamatan, dan Keamanan dan Lingkungan Hidup",
            "Identifikasi Bahaya",
            "Tang Krimping",
            "Cassing",
            "Proses Perakitan",
            "Kode Suara Beep",
            "Sistem",
            "Android",
            "CLI dan GUI",
            "Driver"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_evaluasi);

        kuis = findViewById(R.id.kuis);
        rg = findViewById(R.id.pilihan);
        PilihanA = findViewById(R.id.pilihanA);
        PilihanB = findViewById(R.id.pilihanB);
        PilihanC = findViewById(R.id.pilihanC);
        PilihanD = findViewById(R.id.pilihanD);
        kuis.setText(soal_kuis[nomor]);
        PilihanA.setText(pilihan_jawaban[0]);
        PilihanB.setText(pilihan_jawaban[1]);
        PilihanC.setText(pilihan_jawaban[2]);
        PilihanD.setText(pilihan_jawaban[3]);
        rg.check(0);
        benar = 0;
        salah = 0;
    }
    public void next (View view) {
        if (PilihanA.isChecked() || PilihanB.isChecked() ||
                PilihanC.isChecked() || PilihanD.isChecked()){
            RadioButton jawaban_user =
                    findViewById(rg.getCheckedRadioButtonId());
            String ambil_jawaban_user =
                    jawaban_user.getText().toString();
            rg.check(0);
            if
            (ambil_jawaban_user.equalsIgnoreCase(jawaban[nomor])) benar++;
            else salah++;
            nomor++;
            if (nomor < soal_kuis.length) {
                kuis.setText(soal_kuis[nomor]);
                PilihanA.setText(pilihan_jawaban[(nomor * 4) + 0]);
                PilihanB.setText(pilihan_jawaban[(nomor * 4) + 1]);
                PilihanC.setText(pilihan_jawaban[(nomor * 4) + 2]);
                PilihanD.setText(pilihan_jawaban[(nomor * 4) + 3]);
            }else {
                hasil = benar * 10;
                Intent selesai = new
                        Intent(getApplicationContext(), HasilKuis.class);
                startActivity(selesai);
            }
        }
        else {
            Toast.makeText(this, "Lengkapi Jawaban Terlebih Dahulu", Toast.LENGTH_SHORT).show();
        }
    }
}