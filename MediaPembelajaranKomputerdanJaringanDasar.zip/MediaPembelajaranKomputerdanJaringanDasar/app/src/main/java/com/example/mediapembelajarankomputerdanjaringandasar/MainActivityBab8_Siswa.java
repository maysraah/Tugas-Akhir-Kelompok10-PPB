package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivityBab8_Siswa extends AppCompatActivity {
    private DatabaseReference database;
    ListView listView;
    private ArrayList<Bab8Model> listBab8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bab8_siswa);
        listView = findViewById(R.id.itemsList);

        //menginsiasi database Firebase
        database = FirebaseDatabase.getInstance().getReference();
        populateDataBab8();
    }

    public void populateListview(){
        try {
            ItemListAdapterBab8 itemsAdopter = new ItemListAdapterBab8(this, listBab8);
            listView.setAdapter(itemsAdopter);
            itemsAdopter.notifyDataSetChanged();
            registerForContextMenu(listView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void populateDataBab8 () {
        database.child("Bab 8").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listBab8 = new ArrayList<>();
                for (DataSnapshot materiSnapshot : snapshot.getChildren()) {
                    Bab8Model Bab8 = materiSnapshot.getValue(Bab8Model.class);
                    Bab8.setKey(materiSnapshot.getKey());
                    listBab8.add(Bab8);
                }
                populateListview();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        populateDataBab8();
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu_2, menu);

    }

    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Bab8Model materi = listBab8.get(info.position);
        switch (item.getItemId()) {
            case R.id.detail:
                Intent detail = new Intent(MainActivityBab8_Siswa.this, DetailBab8.class);
                detail.putExtra("key", materi.getkey());
                startActivity(detail);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}