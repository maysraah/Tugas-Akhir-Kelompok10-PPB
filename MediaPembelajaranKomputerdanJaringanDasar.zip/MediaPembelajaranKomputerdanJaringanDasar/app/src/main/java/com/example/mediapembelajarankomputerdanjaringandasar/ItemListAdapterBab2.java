package com.example.mediapembelajarankomputerdanjaringandasar;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ItemListAdapterBab2 extends BaseAdapter{
    private Context context;
    private ArrayList<Bab2Model> arrayList;

    public ItemListAdapterBab2(Context context,ArrayList<Bab2Model> arrayList){
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {
        return this.arrayList.size();
    }

    @Override
    public Object getItem(int posisiton) {
        return arrayList.get(posisiton);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint({"ViewHolder", "InflateParams"})
    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert layoutInflater != null;
        view = layoutInflater.inflate(R.layout.listview_item, null);

        TextView judul_sub = view.findViewById(R.id.judul_sub);
//        TextView detail = view.findViewById(R.id.detail);
        TextView nomer = view.findViewById(R.id.nomer);
        nomer.setText(Integer.toString(position + 1));
        Bab2Model bab2 = arrayList.get(position);
        judul_sub.setText(bab2.getJudul_sub());
//        detail.setText(mahasiswa.getNim() + " | "+mahasiswa.getProdi());

        return view;
    }
}
