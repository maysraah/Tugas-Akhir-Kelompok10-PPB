package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mediapembelajarankomputerdanjaringandasar.modelData.PageBantuan;

public class HalamanBantuan extends AppCompatActivity {
    int indexOfPage = 0;

    //        komponen
    TextView Judul;
    TextView konten;
    ImageView gambar;

    //        tombol navigasi
    Button prev;
    Button next;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_bantuan);

        PageBantuan[] pageBantuans = {
                new PageBantuan("Halaman Materi", R.drawable.materi,R.string.materi),
                new PageBantuan("Halaman Evaluasi", R.drawable.evaluasi,R.string.evaluasi),
                new PageBantuan("Halaman Bantuan", R.drawable.bantuan,R.string.bantuan),
                new PageBantuan("Halaman About Us", R.drawable.about,R.string.about)
        };

        Judul = findViewById(R.id.judul);
        konten = findViewById(R.id.konten);
        gambar = findViewById(R.id.gambar);

        prev = findViewById(R.id.prev);
        next = findViewById(R.id.next);

        tampilkan(pageBantuans[indexOfPage]);
        prev.setOnClickListener(v->{
            if(indexOfPage != 0){
                indexOfPage--;
                tampilkan(pageBantuans[indexOfPage]);
            }else{
                Toast.makeText(this, "habis", Toast.LENGTH_SHORT).show();
            }
        });

        next.setOnClickListener(v->{
            if(indexOfPage != pageBantuans.length-1){
                indexOfPage++;
                tampilkan(pageBantuans[indexOfPage]);
            }else{
                Toast.makeText(this, "habis", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void tampilkan(PageBantuan pageBantuan){
        Judul.setText(pageBantuan.getJudul());
        gambar.setImageResource(pageBantuan.getGambar());
        konten.setText(getString(pageBantuan.getKonten()));
    }
}