package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
public class inputFormBab10 extends AppCompatActivity {

    TextView TVjudul_sub,TVdeskripsi,TvImage;
    private DatabaseReference database;
    String judul_sub,deskripsi, imageName;
    ImageView imagePreview;
    Uri filePath;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    private static final int PICK_IMAGE_REQUEST = 1;
    Button simpan;
    Bab10Model Bab10;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_form_bab10);
        //        mengambil textView
        TVjudul_sub = findViewById(R.id.judul_sub);
        TVdeskripsi = findViewById(R.id.deskripsi);
        TvImage = findViewById(R.id.imageText);
        Button image  = findViewById(R.id.imageButton);
        imagePreview = findViewById(R.id.imagePreview);

        image.setOnClickListener(v->{
            Intent intentMedia = new Intent();
            intentMedia.setType("image/*");
            intentMedia.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intentMedia,"Select Image"), PICK_IMAGE_REQUEST);

        });
//        menginsialisasi database
        database = FirebaseDatabase.getInstance().getReference();

//        tombol simpan.
        simpan = findViewById(R.id.buttonSimpan);
        Intent intent = getIntent();
        String key = intent.getStringExtra("key");
        if(!key.equals("0")){

//            mengambil 1 data berdasarkan key
            database.child("Bab 10").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    String judul_sub = snapshot.child("judul_sub").getValue(String.class);
                    String deskripsi = snapshot.child("deskripsi").getValue(String.class);
                    imageName = snapshot.child("image").getValue(String.class);

                    getSupportActionBar().setTitle("Edit data " + judul_sub);
                    TVjudul_sub.setText(judul_sub);
                    TVdeskripsi.setText(deskripsi);

                    if(imageName!=null){
                        TvImage.setText(imageName);
                        previewImageUriFromStorage(imageName);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    finish();
                }
            });
            Toast.makeText(this, "key "+key, Toast.LENGTH_SHORT).show();



            simpan.setOnClickListener(v->{
                judul_sub = TVjudul_sub.getText().toString();
                deskripsi = TVdeskripsi.getText().toString();
                String newImage = TvImage.getText().toString();
//                membuat hashMap updates yang menyimpan object string
                Map<String, Object> updates = new HashMap<>();
                updates.put("judul_sub", judul_sub);
                updates.put("deskripsi",deskripsi);
                Toast.makeText(this, "gile "+filePath, Toast.LENGTH_SHORT).show();
                if(filePath != null){
                    deleteFiles(imageName);
                    uploadImage(filePath);
                    updates.put("image",getFileName(filePath));
                }

//                mengubdate database berdasarkan key
                database.child("Bab 10").child(key).updateChildren(updates);
                finish();
            });

        }else{
            getSupportActionBar().setTitle("Tambah Data");



            simpan.setOnClickListener(v->{
                judul_sub = TVjudul_sub.getText().toString();
                deskripsi = TVdeskripsi.getText().toString();
                Bab10Model Bab10 = new Bab10Model("",judul_sub,deskripsi);

                if(filePath != null){
                    Bab10.setImage(getFileName(filePath));
                    uploadImage(filePath);
                }
                submitBab10(Bab10);
                finish();
            });
        }
    }

    public void uploadImage(Uri filePath){
        if (filePath != null) {
            // Mendapatkan referensi Firebase Storage
            StorageReference storageRef = storage.getReference();

            // Membuat referensi ke lokasi penyimpanan yang diinginkan dalam Firebase Storage (misalnya, "images")
            StorageReference imagesRef = storageRef.child("images/" + getFileName(filePath));

            // Melakukan unggakan menggunakan putFile dan menambahkan OnSuccessListener dan OnFailureListener
            imagesRef.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            // Unggahan berhasil
                            // Lakukan tindakan yang sesuai, seperti mendapatkan URL unduhan gambar
                            // menggunakan takeSnapshot.getDownloadUrl()
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Unggahan gagal
                            // Tangani kegagalan dengan tindakan yang sesuai
                        }
                    });
        }
    }
    public void submitBab10(Bab10Model Bab10){
        database.child("Bab 10").push().setValue(Bab10).addOnSuccessListener(this, new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(inputFormBab10.this, "Berhasil tambah data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @SuppressLint("Range")
    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result;
    }

    public void deleteFiles(String fileName) {
        StorageReference storageRef = storage.getReference();
        // Create a reference to the file to delete
        StorageReference desertRef = storageRef.child("images/" + fileName);
        desertRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(inputFormBab10.this, "Gambar dihapus dari Firebase Storage", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(inputFormBab10.this, "Gambar gagal dihapus dari Firebase Storage", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void previewImageUriFromStorage(String filename){
        StorageReference storageRef = storage.getReference();
        storageRef.child("images").child(filename).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(imagePreview);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Handle any errors
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            String fileName = getFileName(filePath);
            TvImage.setText(fileName);
            // Menampilkan gambar ke preview
            Picasso.get().load(filePath).into(imagePreview);
        }
    }
}