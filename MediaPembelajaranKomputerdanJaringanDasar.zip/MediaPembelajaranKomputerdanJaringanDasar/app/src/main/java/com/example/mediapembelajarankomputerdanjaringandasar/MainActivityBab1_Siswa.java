package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivityBab1_Siswa extends AppCompatActivity {
    private DatabaseReference database;
    ListView listView;
    private ArrayList<Bab1Model> listBab1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bab1_siswa);
        listView = findViewById(R.id.itemsList);

        //menginsiasi database Firebase
        database = FirebaseDatabase.getInstance().getReference();
        populateDataBab1();
    }

    public void populateListview(){
        try {
            ItemListAdapterBab1 itemsAdopter = new ItemListAdapterBab1(this, listBab1);
            listView.setAdapter(itemsAdopter);
            itemsAdopter.notifyDataSetChanged();
            registerForContextMenu(listView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void populateDataBab1 () {
        database.child("Bab 1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listBab1 = new ArrayList<>();
                for (DataSnapshot materiSnapshot : snapshot.getChildren()) {
                    Bab1Model Bab1 = materiSnapshot.getValue(Bab1Model.class);
                    Bab1.setKey(materiSnapshot.getKey());
                    listBab1.add(Bab1);
                }
                populateListview();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        populateDataBab1();
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu_2, menu);

    }

    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Bab1Model materi = listBab1.get(info.position);
        switch (item.getItemId()) {
            case R.id.detail:
                Intent detail = new Intent(MainActivityBab1_Siswa.this, DetailBab1.class);
                detail.putExtra("key", materi.getkey());
                startActivity(detail);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}