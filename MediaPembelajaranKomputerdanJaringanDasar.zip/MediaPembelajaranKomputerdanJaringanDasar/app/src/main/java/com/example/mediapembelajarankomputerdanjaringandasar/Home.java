package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Home extends AppCompatActivity {

    CardView cardMateri;
    CardView cardEvaluasi;
    CardView cardBantuan;
    CardView cardAboutUs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cardMateri = findViewById(R.id.cardMateri);
        cardEvaluasi = findViewById(R.id.cardEvaluasi);
        cardBantuan = findViewById(R.id.cardBantuan);
        cardAboutUs = findViewById(R.id.cardAboutUs);

        cardMateri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Materi cliked");
                startActivity(new Intent(Home.this, HalamanMateri.class));
            }
        });
        cardEvaluasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Evaluasi cliked");
                startActivity(new Intent(Home.this, HalamanEvaluasi.class));
            }
        });
        cardBantuan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("Bantuan cliked");
                startActivity(new Intent(Home.this, HalamanBantuan.class));
            }
        });
        cardAboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("AbouUs cliked");
                startActivity(new Intent(Home.this, HalamanAboutUs.class));
            }
        });

    }
    private void showToast(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}