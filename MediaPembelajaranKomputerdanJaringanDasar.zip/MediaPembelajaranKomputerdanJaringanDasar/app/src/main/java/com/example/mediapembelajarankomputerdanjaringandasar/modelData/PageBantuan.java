package com.example.mediapembelajarankomputerdanjaringandasar.modelData;

public class PageBantuan {
    String Judul;
    int Gambar;
    int konten;

    public PageBantuan(String judul, int gambar, int konten) {
        Judul = judul;
        Gambar = gambar;
        this.konten = konten;
    }

    public String getJudul() {
        return Judul;
    }

    public int getGambar() {
        return Gambar;
    }

    public int getKonten() {
        return konten;
    }
}
