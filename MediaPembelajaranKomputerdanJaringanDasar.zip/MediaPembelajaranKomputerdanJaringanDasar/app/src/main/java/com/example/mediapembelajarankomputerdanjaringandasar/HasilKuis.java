package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HasilKuis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_kuis);

        TextView hasil = findViewById(R.id.hasil);
        TextView nilai = findViewById(R.id.nilai);
        hasil.setText("Jawaban benar : "+HalamanEvaluasi.benar+"\nJawaban salah :" +HalamanEvaluasi.salah);
        nilai.setText(""+HalamanEvaluasi.hasil);
    }

    public void ulangi(View view) {
        finish();
        Intent ulang = new Intent(getApplicationContext(), HalamanEvaluasi.class);
        startActivity(ulang);
    }
    public void kembali(View view) {
        finish();
        Intent kembali = new Intent(getApplicationContext(), Home.class);
        startActivity(kembali);
    }
}