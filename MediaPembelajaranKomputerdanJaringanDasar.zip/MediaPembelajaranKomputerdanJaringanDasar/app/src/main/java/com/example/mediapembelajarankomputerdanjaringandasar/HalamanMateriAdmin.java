package com.example.mediapembelajarankomputerdanjaringandasar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;

public class HalamanMateriAdmin extends Activity {

    CardView cardMateri1;
    CardView cardMateri2;
    CardView cardMateri3;
    CardView cardMateri4;
    CardView cardMateri5;
    CardView cardMateri6;
    CardView cardMateri7;
    CardView cardMateri8;
    CardView cardMateri9;
    CardView cardMateri10;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_materi_admin);

        cardMateri1 = findViewById(R.id.cardMateri1);
        cardMateri2 = findViewById(R.id.cardMateri2);
        cardMateri3 = findViewById(R.id.cardMateri3);
        cardMateri4 = findViewById(R.id.cardMateri4);
        cardMateri5 = findViewById(R.id.cardMateri5);
        cardMateri6 = findViewById(R.id.cardMateri6);
        cardMateri7 = findViewById(R.id.cardMateri7);
        cardMateri8 = findViewById(R.id.cardMateri8);
        cardMateri9 = findViewById(R.id.cardMateri9);
        cardMateri10 = findViewById(R.id.cardMateri10);

        cardMateri1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab1.class));
            }
        });
        cardMateri2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab2.class));
            }
        });
        cardMateri3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab3.class));
            }
        });
        cardMateri4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab4.class));
            }
        });
        cardMateri5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab5.class));
            }
        });
        cardMateri6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab6.class));
            }
        });
        cardMateri7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab7.class));
            }
        });
        cardMateri8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab8.class));
            }
        });
        cardMateri9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab9.class));
            }
        });
        cardMateri10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HalamanMateriAdmin.this, MainActivityBab10.class));
            }
        });
    }
}