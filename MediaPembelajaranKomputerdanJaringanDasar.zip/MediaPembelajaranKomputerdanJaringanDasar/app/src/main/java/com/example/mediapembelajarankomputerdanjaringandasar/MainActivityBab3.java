package com.example.mediapembelajarankomputerdanjaringandasar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class MainActivityBab3 extends AppCompatActivity {
    private DatabaseReference database;
    ListView listView;
    FloatingActionButton FAB;
    private ArrayList<Bab3Model> listBab3;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_bab3);
        listView = findViewById(R.id.itemsList);
        FAB = findViewById(R.id.tambahData);

        //menginsiasi database Firebase
        database = FirebaseDatabase.getInstance().getReference();
        populateDataBab3();

        FAB.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivityBab3.this, inputFormBab3.class);
            intent.putExtra("key", "0");
            startActivity(intent);
        });
    }

    public void populateListview(){
        try {
            ItemListAdapterBab3 itemsAdopter = new ItemListAdapterBab3(this, listBab3);
            listView.setAdapter(itemsAdopter);
            itemsAdopter.notifyDataSetChanged();
            registerForContextMenu(listView);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void populateDataBab3 () {
        database.child("Bab 3").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listBab3 = new ArrayList<>();
                for (DataSnapshot mahasiswaSnapshot : snapshot.getChildren()) {
                    Bab3Model Bab3 = mahasiswaSnapshot.getValue(Bab3Model.class);
                    Bab3.setKey(mahasiswaSnapshot.getKey());
                    listBab3.add(Bab3);
                }
                populateListview();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        populateDataBab3();
    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);

    }
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Bab3Model materi = listBab3.get(info.position);
        switch (item.getItemId()) {
            case R.id.edit:
                Intent intent = new Intent(MainActivityBab3.this, inputFormBab3.class);
                intent.putExtra("key",materi.getkey());
                startActivity(intent);
                return true;
            case R.id.detail:
                Intent detail = new Intent(MainActivityBab3.this, DetailBab3.class);
                detail.putExtra("key",materi.getkey());
                startActivity(detail);
                return true;
            case R.id.delete:
                showConfirmationDialog(materi.getkey());
                populateDataBab3();
                deleteImageFromStorage(materi.image);

                return true;
            default:
                return super.onContextItemSelected(item);
        }

    }

    public void showConfirmationDialog(String key) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Konfirmasi")
                .setMessage("Apakah Anda yakin ingin menghapus data?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        database.child("Bab 3").child(key).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(MainActivityBab3.this, "Data dihapus!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                })
                .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Tindakan yang dilakukan ketika user menekan tombol Tidak
                        // Contoh: tutup dialog
                        dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    private void deleteImageFromStorage(String imageName) {
        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        StorageReference imageRef = storageRef.child("images").child(imageName);

        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                // Gambar berhasil dihapus dari storage
                Toast.makeText(MainActivityBab3.this, "Gambar dihapus dari storage", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // Gagal menghapus gambar dari storage
                Toast.makeText(MainActivityBab3.this, "Gagal menghapus gambar dari storage", Toast.LENGTH_SHORT).show();
            }
        });
    }
}